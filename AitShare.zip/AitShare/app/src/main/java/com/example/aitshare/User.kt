package com.example.aitshare

data class User(var username: String? = "", var password: String? = "", var year: String? = "", var id: String?="")