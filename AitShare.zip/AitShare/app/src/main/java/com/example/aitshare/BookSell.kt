package com.example.aitshare

data class BookSell(
    var book_year : String?="",
    var book_info : String?="",
    var amount : String?="",
    var college_id : String?="",
    var username : String?="",
    var contact : String?=""
    )